using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cell
{
    public bool occ;
    public float cost;
    public float utility;
    public bool explored;

    public Cell(bool Occ, bool _explored)
    {
        occ = Occ;
        //cost = V;
        //utility = U;
        explored = _explored;
    }
}

public class Grid
{
    public float maxLen;
    public float maxBr;
    public float cellSize;
    public Cell[,] grid;

    public Grid(float length, float breadth, float cell)
    {
        maxLen = length;
        maxBr = breadth;
        cellSize = cell;

        grid = new Cell[Mathf.RoundToInt(maxLen / cellSize) - 1, Mathf.RoundToInt(maxBr / cellSize) - 1];
    }

    public Vector2 Coordinate(Vector3 position)
    {
        int x = Mathf.RoundToInt(position.x / cellSize + maxLen/2/cellSize);
        int y = Mathf.RoundToInt(position.z / cellSize + maxBr / 2 / cellSize);
        return new Vector2(x,y);
    }
    
    public float Pocc(int x, int y)
    {
        float P =0;
        return P;
    }

    public float Cost(int x, int y)
    {
        float P = 0;
        return P;
    }

    public float Utility(int x, int y)
    {
        float P = 0;
        return P;
    }
}
